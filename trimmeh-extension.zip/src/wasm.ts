import GLib from 'gi://GLib';
import Gio from 'gi://Gio';

export type Aggressiveness = 'low' | 'normal' | 'high';

export interface TrimOptions {
    keep_blank_lines: boolean;
    strip_box_chars: boolean;
    trim_prompts: boolean;
    max_lines: number;
}

export interface TrimResponse {
    output: string;
    changed: boolean;
    reason?: string;
    hash_hex: string;
}

export interface Trimmer {
    trim(text: string, aggressiveness: Aggressiveness, options: TrimOptions): TrimResponse;
}

const WASM_FILE = 'wasm/libtrimmeh_core_bg.wasm';
const GLUE_FILE = 'wasm/libtrimmeh_core.js';

export async function createWasmTrimAdapter(basePath: string): Promise<Trimmer> {
    log('Trimmeh: initializing wasm adapter');
    try {
        const gluePath = GLib.build_filenamev([basePath, GLUE_FILE]);
        const wasmPath = GLib.build_filenamev([basePath, WASM_FILE]);

        // Load and evaluate the wasm-bindgen no-modules glue, which sets a global `wasm_bindgen`.
        loadGlue(gluePath);

        const wasmBytes = readFileBytes(wasmPath);
        // Prefer sync init to avoid async footgun in Shell init; falls back to async if ever needed.
        if (typeof (globalThis as any).wasm_bindgen?.initSync === 'function') {
            (globalThis as any).wasm_bindgen.initSync({ module: wasmBytes });
        } else if (typeof (globalThis as any).wasm_bindgen === 'function') {
            await (globalThis as any).wasm_bindgen(wasmBytes);
        } else {
            throw new Error('wasm_bindgen glue missing after eval');
        }

        const trimFn = (globalThis as any).wasm_bindgen?.trim_js;
        if (typeof trimFn !== 'function') {
            throw new Error('wasm_bindgen glue missing trim_js() export');
        }

        log('Trimmeh: wasm adapter ready');
        return {
            trim: (text: string, aggressiveness: Aggressiveness, options: TrimOptions): TrimResponse => {
                const aggrCode = aggressivenessToCode(aggressiveness);
                const res: any = trimFn(text, aggrCode, options);
                return {
                    output: res?.output ?? text,
                    changed: Boolean(res?.changed),
                    reason: res?.reason ?? undefined,
                    hash_hex: res?.hash_hex ?? '',
                };
            },
        };
    } catch (e) {
        log(`Trimmeh wasm adapter failed, falling back to no-op: ${e}`);
        return {
            trim: (text: string): TrimResponse => ({
                output: text,
                changed: false,
                reason: undefined,
                hash_hex: '',
            }),
        };
    }
}

function loadGlue(gluePath: string): void {
    const glueFile = Gio.File.new_for_path(gluePath);
    const [, contents] = glueFile.load_contents(null);
    let source: string;
    if (typeof TextDecoder !== 'undefined') {
        const decoder = new TextDecoder('utf-8');
        source = decoder.decode(contents as unknown as Uint8Array);
    } else if ((globalThis as any).imports?.byteArray?.toString) {
        // Fallback for environments without TextDecoder (older gjs builds).
        source = (globalThis as any).imports.byteArray.toString(contents);
    } else {
        // Last-resort, slow path.
        const bytes = contents as unknown as Uint8Array;
        source = Array.from(bytes).map(b => String.fromCharCode(b)).join('');
    }
    // Evaluate and capture the wasm_bindgen binding (let inside glue doesn't become a global property).
    try {
        const wbg = (0, eval)(`${source}\nwasm_bindgen`);
        if (!wbg) {
            throw new Error('wasm_bindgen not exported from glue');
        }
        (globalThis as any).wasm_bindgen = wbg;
    } catch (e) {
        log(`Trimmeh wasm glue eval failed: ${e}`);
        // Leave wasm_bindgen unset so caller falls back to no-op.
    }
}

function readFileBytes(path: string): Uint8Array {
    const file = Gio.File.new_for_path(path);
    const [, contents] = file.load_contents(null);
    return contents instanceof Uint8Array ? contents : Uint8Array.from(contents as unknown as number[]);
}

function aggressivenessToCode(level: Aggressiveness): number {
    switch (level) {
        case 'low':
            return 0;
        case 'high':
            return 2;
        case 'normal':
        default:
            return 1;
    }
}
