import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import {PanelIndicator} from './panel.js';
import * as ExtensionUtils from 'resource:///org/gnome/shell/misc/extensionUtils.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {ClipboardWatcher} from './clipboard.js';
import {createWasmTrimAdapter} from './wasm.js';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import St from 'gi://St';

export default class TrimmehExtension extends Extension {
    private watcher: ClipboardWatcher | null = null;
    private panelIndicator: PanelIndicator | null = null;
    private keybindings: string[] = [];

    async enable(): Promise<void> {
        const settings = this.getSettings();
        const trimmer = await createWasmTrimAdapter(this.dir.get_path());
        this.watcher = new ClipboardWatcher(trimmer, settings);
        this.watcher.enable();

        this.panelIndicator = new PanelIndicator(settings, this.watcher, () => {
            this.openPreferences();
        });
        this.panelIndicator.addToPanel();

        this.registerKeybindings(settings);
    }

    disable(): void {
        this.unregisterKeybindings();
        this.watcher?.disable();
        this.watcher = null;
        this.panelIndicator?.destroy();
        this.panelIndicator = null;
    }

    private registerKeybindings(settings: any): void {
        const modes = Shell.ActionMode.ALL;
        const add = (name: string, handler: () => void) => {
            if (Main.wm.addKeybinding(name, settings, Meta.KeyBindingFlags.NONE, modes, handler)) {
                this.keybindings.push(name);
            }
        };
        add('paste-trimmed-accelerator', () => {
            this.watcher?.pasteTrimmed(St.ClipboardType.CLIPBOARD).catch(logError);
        });
        add('paste-original-accelerator', () => {
            this.watcher?.pasteOriginal(St.ClipboardType.CLIPBOARD).catch(logError);
        });
        add('toggle-auto-accelerator', () => {
            if (this.watcher) {
                const current = settings.get_boolean('enable-auto-trim');
                settings.set_boolean('enable-auto-trim', !current);
            }
        });
    }

    private unregisterKeybindings(): void {
        this.keybindings.forEach(name => {
            Main.wm.removeKeybinding(name);
        });
        this.keybindings = [];
    }
}
