import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import St from 'gi://St';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {ClipboardWatcher} from './clipboard.js';

const PanelIndicatorClass = GObject.registerClass(
class TrimmehPanelIndicator extends PanelMenu.Button {
    private settings!: Gio.Settings;
    private watcher!: ClipboardWatcher;
    private autoItem!: PopupMenu.PopupSwitchMenuItem;
    private openPrefs?: () => void;
    private statusItem!: PopupMenu.PopupMenuItem;

    _init(settings: Gio.Settings, watcher: ClipboardWatcher, openPrefs?: () => void) {
        super._init(0.0, 'Trimmeh!');
        this.settings = settings;
        this.watcher = watcher;
        this.openPrefs = openPrefs;

        const icon = new St.Icon({ icon_name: 'edit-cut-symbolic', style_class: 'system-status-icon' });
        this.add_child(icon);

        this.autoItem = new PopupMenu.PopupSwitchMenuItem(
            'Auto trim clipboard',
            this.settings.get_boolean('enable-auto-trim'),
        );
        this.autoItem.connect('toggled', (_item, state: boolean) => {
            this.settings.set_boolean('enable-auto-trim', state);
        });

        const trimNow = new PopupMenu.PopupMenuItem('Trim clipboard now');
        trimNow.connect('activate', () => {
            this.watcher.trimNow(St.ClipboardType.CLIPBOARD, true).catch(logError);
        });

        const pasteTrimmed = new PopupMenu.PopupMenuItem('Paste trimmed (temp replace clipboard)');
        pasteTrimmed.connect('activate', () => {
            this.watcher.pasteTrimmed(St.ClipboardType.CLIPBOARD).catch(logError);
        });

        const restoreItem = new PopupMenu.PopupMenuItem('Restore last copy');
        restoreItem.connect('activate', () => {
            this.watcher.restore(St.ClipboardType.CLIPBOARD);
        });

        const pasteOriginal = new PopupMenu.PopupMenuItem('Paste original (temp replace clipboard)');
        pasteOriginal.connect('activate', () => {
            this.watcher.pasteOriginal(St.ClipboardType.CLIPBOARD).catch(logError);
        });

        const prefsItem = new PopupMenu.PopupMenuItem('Preferences…');
        prefsItem.connect('activate', () => {
            if (this.openPrefs) {
                this.openPrefs();
            } else {
                log('Trimmeh: preferences callback not set');
            }
        });

        this.statusItem = new PopupMenu.PopupMenuItem(this.watcher.getStatus());
        this.statusItem.setSensitive(false);

        this.menu.addMenuItem(this.autoItem);
        this.menu.addMenuItem(trimNow);
        this.menu.addMenuItem(pasteTrimmed);
        this.menu.addMenuItem(pasteOriginal);
        this.menu.addMenuItem(restoreItem);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addMenuItem(this.statusItem);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addMenuItem(prefsItem);

        this.settings.connect('changed::enable-auto-trim', () => {
            this.autoItem.setToggleState(this.settings.get_boolean('enable-auto-trim'));
        });

        this.menu.connect('open-state-changed', (_m, isOpen: boolean) => {
            if (isOpen) {
                this.statusItem.label.set_text(this.watcher.getStatus());
            }
        });
    }

    addToPanel(): void {
        Main.panel.addToStatusArea('trimmeh-panel', this);
    }

    destroy(): void {
        super.destroy();
    }
});

export {PanelIndicatorClass as PanelIndicator};
