import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';
import Gio from 'gi://Gio';
import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class TrimmehPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window: Adw.PreferencesWindow): void {
        const settings = this.getSettings();
        const page = new Adw.PreferencesPage({title: 'Trimmeh'});
        const toggles = new Adw.PreferencesGroup({title: 'Behavior'});

        toggles.add(this.switchRow('Enable auto trim', settings, 'enable-auto-trim'));
        toggles.add(this.switchRow('Strip shell prompts', settings, 'trim-prompts'));
        toggles.add(this.switchRow('Strip box gutters', settings, 'strip-box-chars'));
        toggles.add(this.switchRow('Keep blank lines', settings, 'keep-blank-lines'));

        const aggrRow = this.aggressivenessRow(settings);
        toggles.add(aggrRow);

        const maxLinesRow = new Adw.ActionRow({
            title: 'Maximum lines to process',
            subtitle: 'Skip blobs beyond this line count',
        });
        const spin = new Gtk.SpinButton({
            adjustment: new Gtk.Adjustment({
                lower: 1,
                upper: 1000,
                step_increment: 1,
                page_increment: 5,
                value: settings.get_int('max-lines'),
            }),
        });
        settings.bind('max-lines', spin, 'value', Gio.SettingsBindFlags.DEFAULT);
        maxLinesRow.add_suffix(spin);
        maxLinesRow.set_activatable_widget(spin);
        toggles.add(maxLinesRow);

        const shortcuts = new Adw.PreferencesGroup({title: 'Shortcuts'});
        shortcuts.add(this.accelRow(
            'Paste trimmed',
            settings,
            'paste-trimmed-accelerator',
            'e.g. <Primary><Alt>T',
        ));
        shortcuts.add(this.accelRow(
            'Paste original',
            settings,
            'paste-original-accelerator',
            'e.g. <Primary><Alt><Shift>T',
        ));
        shortcuts.add(this.accelRow(
            'Toggle auto-trim',
            settings,
            'toggle-auto-accelerator',
            'e.g. <Primary><Alt>A',
        ));

        const info = new Adw.PreferencesGroup({title: 'Manual actions'});
        info.add(new Adw.ActionRow({
            title: 'Manual trim/restore will arrive in the Shell UI',
            subtitle: 'Prefs cannot access the live clipboard; use the extension menu once implemented.',
            activatable: false,
        }));

        page.add(toggles);
        page.add(shortcuts);
        page.add(info);
        window.add(page);
        window.set_default_size(520, 520);
    }

    private switchRow(title: string, settings: Gio.Settings, key: string): Adw.ActionRow {
        const row = new Adw.ActionRow({title});
        const sw = new Gtk.Switch({valign: Gtk.Align.CENTER});
        settings.bind(key, sw, 'active', Gio.SettingsBindFlags.DEFAULT);
        row.add_suffix(sw);
        row.set_activatable_widget(sw);
        return row;
    }

    private aggressivenessRow(settings: Gio.Settings): Adw.ActionRow {
        const strings = new Gtk.StringList();
        ['low', 'normal', 'high'].forEach(s => strings.append(s));
        const row = new Adw.ComboRow({
            title: 'Aggressiveness',
            model: strings,
        });
        const current = settings.get_string('aggressiveness');
        row.selected = ['low', 'normal', 'high'].indexOf(current);
        row.connect('notify::selected', () => {
            const value = strings.get_string(row.selected);
            if (value) settings.set_string('aggressiveness', value);
        });
        settings.connect('changed::aggressiveness', () => {
            const idx = ['low', 'normal', 'high'].indexOf(settings.get_string('aggressiveness'));
            row.selected = idx >= 0 ? idx : 1;
        });
        return row;
    }

    private accelRow(title: string, settings: Gio.Settings, key: string, placeholder: string): Adw.ActionRow {
        const row = new Adw.ActionRow({title});
        const entry = new Gtk.Entry({
            placeholder_text: placeholder,
            valign: Gtk.Align.CENTER,
        });
        const updateFromSettings = () => {
            const vals = settings.get_strv(key);
            entry.text = vals.length > 0 ? vals[0] : '';
        };
        updateFromSettings();
        entry.connect('changed', () => {
            const val = entry.text.trim();
            if (val.length === 0) {
                settings.set_strv(key, []);
            } else {
                settings.set_strv(key, [val]);
            }
        });
        settings.connect(`changed::${key}`, updateFromSettings);
        row.add_suffix(entry);
        row.set_activatable_widget(entry);
        return row;
    }
}
