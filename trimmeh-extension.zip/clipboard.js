// shell-extension/src/clipboard.ts
import St from "gi://St";
import GLib from "gi://GLib";
var ClipboardWatcher = class {
  constructor(trimmer, settings) {
    this.trimmer = trimmer;
    this.settings = settings;
    this.clipboard = St.Clipboard.get_default();
    this.signals = [];
    this.lastOriginal = /* @__PURE__ */ new Map();
    // Records the last write we performed per selection so we can skip
    // retrimming a manual restore while still trimming fresh copies.
    this.lastWrite = /* @__PURE__ */ new Map();
    // Guards to ensure a restored payload is not immediately re-trimmed even if
    // GNOME emits multiple owner-change events or normalizes text.
    this.restoreGuards = /* @__PURE__ */ new Map();
    this.pollId = null;
    this.pendingReads = /* @__PURE__ */ new Map();
    this.graceDelayMs = 80;
    this.lastStatus = "No actions yet";
  }
  enable() {
    try {
      const handler = (_clip, selection) => {
        this.scheduleOwnerChange(selection);
      };
      this.signals.push(this.clipboard.connect("owner-change", handler));
    } catch (e) {
      log(`owner-change not available, falling back to polling: ${e}`);
      this.startPolling();
    }
    [St.ClipboardType.CLIPBOARD, St.ClipboardType.PRIMARY].forEach((sel) => {
      this.onOwnerChange(sel).catch(logError);
    });
  }
  disable() {
    this.signals.forEach((sig) => this.clipboard.disconnect(sig));
    this.signals = [];
    if (this.pollId !== null) {
      GLib.source_remove(this.pollId);
      this.pollId = null;
    }
    this.pendingReads.forEach((id) => GLib.source_remove(id));
    this.pendingReads.clear();
  }
  scheduleOwnerChange(selection) {
    if (this.pendingReads.has(selection)) {
      return;
    }
    const id = GLib.timeout_add(GLib.PRIORITY_DEFAULT, this.graceDelayMs, () => {
      this.pendingReads.delete(selection);
      this.onOwnerChange(selection).catch(logError);
      return GLib.SOURCE_REMOVE;
    });
    this.pendingReads.set(selection, id);
  }
  async onOwnerChange(selection) {
    const text = await this.readText(selection);
    if (!text) {
      return;
    }
    const now = GLib.get_monotonic_time();
    const guard = this.restoreGuards.get(selection);
    if (guard) {
      if (now > guard.expires) {
        this.restoreGuards.delete(selection);
      } else {
        const hash = hashText(text);
        if (hash === guard.hash) {
          log(`Trimmeh: skip owner-change after restore (selection=${selection})`);
          return;
        }
        this.restoreGuards.delete(selection);
      }
    }
    const last = this.lastWrite.get(selection);
    if (last) {
      const incomingHash = hashText(text);
      if (last.kind === "restore" || last.kind === "trim" && hashText(last.text) === incomingHash) {
        this.lastWrite.delete(selection);
        return;
      }
    }
    if (!this.settings.get_boolean("enable-auto-trim")) {
      return;
    }
    const opts = this.readOptions();
    const aggr = this.settings.get_string("aggressiveness");
    const result = this.trimmer.trim(text, aggr, opts);
    if (!result.changed) {
      this.setStatus("No change (auto)");
      return;
    }
    this.lastOriginal.set(selection, text);
    this.clipboard.set_text(selection, result.output);
    this.lastWrite.set(selection, { kind: "trim", text: result.output });
    this.setStatus("Auto-trimmed clipboard");
  }
  startPolling() {
    this.pollId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 800, () => {
      [St.ClipboardType.CLIPBOARD, St.ClipboardType.PRIMARY].forEach((sel) => {
        this.scheduleOwnerChange(sel);
      });
      return GLib.SOURCE_CONTINUE;
    });
  }
  readOptions() {
    return {
      keep_blank_lines: this.settings.get_boolean("keep-blank-lines"),
      strip_box_chars: this.settings.get_boolean("strip-box-chars"),
      trim_prompts: this.settings.get_boolean("trim-prompts"),
      max_lines: this.settings.get_int("max-lines")
    };
  }
  readText(selection) {
    return new Promise((resolve) => {
      this.clipboard.get_text(selection, (_clip, text) => {
        if (text) {
          resolve(text);
          return;
        }
        this.clipboard.get_text(selection, (_clip2, text2) => {
          resolve(text2);
        });
      });
    });
  }
  /** Manual: trim current clipboard (optionally force High) and write back. Returns true if changed or forced. */
  async trimNow(selection, forceHigh) {
    const text = await this.readText(selection);
    if (!text) {
      this.setStatus("Nothing to trim");
      return false;
    }
    const opts = this.readOptions();
    const aggr = forceHigh ? "high" : this.settings.get_string("aggressiveness");
    const result = this.trimmer.trim(text, aggr, opts);
    if (!result.changed && !forceHigh) {
      this.setStatus("No trim applied");
      return false;
    }
    this.lastOriginal.set(selection, text);
    await this.setClipboardWithMarker(selection, result.output, "trim");
    this.setStatus("Clipboard trimmed");
    return true;
  }
  /** Paste trimmed: temporarily set clipboard to trimmed version, schedule restore. */
  async pasteTrimmed(selection) {
    const text = await this.readText(selection);
    if (!text) {
      this.setStatus("Nothing to trim");
      return false;
    }
    const opts = this.readOptions();
    const result = this.trimmer.trim(text, "high", opts);
    if (!result.changed) {
      this.setStatus("No trim needed");
      return false;
    }
    const previous = text;
    this.lastOriginal.set(selection, previous);
    await this.setClipboardWithMarker(selection, result.output, "trim");
    this.scheduleRestore(selection, previous);
    this.setStatus("Paste trimmed ready (clipboard restores shortly)");
    return true;
  }
  /** Paste original: temporarily put original back on clipboard, then restore trimmed copy. */
  async pasteOriginal(selection) {
    const current = await this.readText(selection);
    const original = this.lastOriginal.get(selection) ?? current;
    if (!original) {
      this.setStatus("No original cached");
      return false;
    }
    await this.setClipboardWithMarker(selection, original, "restore");
    this.scheduleRestore(selection, current ?? original);
    this.setStatus("Paste original ready (clipboard restores shortly)");
    return true;
  }
  /** Exposed for panel status line. */
  getStatus() {
    return this.lastStatus;
  }
  setStatus(msg) {
    this.lastStatus = msg;
    log(`Trimmeh: ${msg}`);
  }
  async setClipboardWithMarker(selection, text, kind) {
    const hash = hashText(text);
    const expires = GLib.get_monotonic_time() + 15e5;
    this.restoreGuards.set(selection, { hash, expires });
    this.clipboard.set_text(selection, text);
    this.lastWrite.set(selection, { kind, text });
  }
  scheduleRestore(selection, previous) {
    if (!previous) {
      return;
    }
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 400, () => {
      this.clipboard.set_text(selection, previous);
      this.lastWrite.set(selection, { kind: "restore", text: previous });
      this.setStatus("Clipboard restored");
      return GLib.SOURCE_REMOVE;
    });
  }
  restore(selection) {
    const original = this.lastOriginal.get(selection);
    if (original) {
      const hash = hashText(original);
      const expires = GLib.get_monotonic_time() + 15e5;
      this.restoreGuards.set(selection, { hash, expires });
      log(`Trimmeh: restore requested (selection=${selection}) hash=${hash}`);
      this.clipboard.set_text(selection, original);
      this.lastWrite.set(selection, { kind: "restore", text: original });
    }
  }
};
function hashText(text) {
  return GLib.compute_checksum_for_string(GLib.ChecksumType.SHA256, text, -1);
}
export {
  ClipboardWatcher
};
