// shell-extension/src/wasm.ts
import GLib from "gi://GLib";
import Gio from "gi://Gio";
var WASM_FILE = "wasm/libtrimmeh_core_bg.wasm";
var GLUE_FILE = "wasm/libtrimmeh_core.js";
async function createWasmTrimAdapter(basePath) {
  log("Trimmeh: initializing wasm adapter");
  try {
    const gluePath = GLib.build_filenamev([basePath, GLUE_FILE]);
    const wasmPath = GLib.build_filenamev([basePath, WASM_FILE]);
    loadGlue(gluePath);
    const wasmBytes = readFileBytes(wasmPath);
    if (typeof globalThis.wasm_bindgen?.initSync === "function") {
      globalThis.wasm_bindgen.initSync({ module: wasmBytes });
    } else if (typeof globalThis.wasm_bindgen === "function") {
      await globalThis.wasm_bindgen(wasmBytes);
    } else {
      throw new Error("wasm_bindgen glue missing after eval");
    }
    const trimFn = globalThis.wasm_bindgen?.trim_js;
    if (typeof trimFn !== "function") {
      throw new Error("wasm_bindgen glue missing trim_js() export");
    }
    log("Trimmeh: wasm adapter ready");
    return {
      trim: (text, aggressiveness, options) => {
        const aggrCode = aggressivenessToCode(aggressiveness);
        const res = trimFn(text, aggrCode, options);
        return {
          output: res?.output ?? text,
          changed: Boolean(res?.changed),
          reason: res?.reason ?? void 0,
          hash_hex: res?.hash_hex ?? ""
        };
      }
    };
  } catch (e) {
    log(`Trimmeh wasm adapter failed, falling back to no-op: ${e}`);
    return {
      trim: (text) => ({
        output: text,
        changed: false,
        reason: void 0,
        hash_hex: ""
      })
    };
  }
}
function loadGlue(gluePath) {
  const glueFile = Gio.File.new_for_path(gluePath);
  const [, contents] = glueFile.load_contents(null);
  let source;
  if (typeof TextDecoder !== "undefined") {
    const decoder = new TextDecoder("utf-8");
    source = decoder.decode(contents);
  } else if (globalThis.imports?.byteArray?.toString) {
    source = globalThis.imports.byteArray.toString(contents);
  } else {
    const bytes = contents;
    source = Array.from(bytes).map((b) => String.fromCharCode(b)).join("");
  }
  try {
    const wbg = (0, eval)(`${source}
wasm_bindgen`);
    if (!wbg) {
      throw new Error("wasm_bindgen not exported from glue");
    }
    globalThis.wasm_bindgen = wbg;
  } catch (e) {
    log(`Trimmeh wasm glue eval failed: ${e}`);
  }
}
function readFileBytes(path) {
  const file = Gio.File.new_for_path(path);
  const [, contents] = file.load_contents(null);
  return contents instanceof Uint8Array ? contents : Uint8Array.from(contents);
}
function aggressivenessToCode(level) {
  switch (level) {
    case "low":
      return 0;
    case "high":
      return 2;
    case "normal":
    default:
      return 1;
  }
}
export {
  createWasmTrimAdapter
};
