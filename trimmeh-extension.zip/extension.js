// shell-extension/src/extension.ts
import { Extension } from "resource:///org/gnome/shell/extensions/extension.js";

// shell-extension/src/panel.ts
import GObject from "gi://GObject";
import St from "gi://St";
import * as PanelMenu from "resource:///org/gnome/shell/ui/panelMenu.js";
import * as PopupMenu from "resource:///org/gnome/shell/ui/popupMenu.js";
import * as Main from "resource:///org/gnome/shell/ui/main.js";
var PanelIndicatorClass = GObject.registerClass(
  class TrimmehPanelIndicator extends PanelMenu.Button {
    _init(settings, watcher, openPrefs) {
      super._init(0, "Trimmeh");
      this.settings = settings;
      this.watcher = watcher;
      this.openPrefs = openPrefs;
      this.icon = new St.Icon({ icon_name: "edit-cut-symbolic", style_class: "system-status-icon" });
      this.add_child(this.icon);
      this.summaryItem = new PopupMenu.PopupMenuItem("No actions yet", {
        reactive: false,
        can_focus: false
      });
      this.menu.addMenuItem(this.summaryItem);
      this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
      this.autoItem = new PopupMenu.PopupSwitchMenuItem(
        "Auto trim clipboard",
        this.settings.get_boolean("enable-auto-trim")
      );
      this.autoItem.connect("toggled", (_item, state) => {
        this.settings.set_boolean("enable-auto-trim", state);
      });
      const pasteTrimmedItem = new PopupMenu.PopupMenuItem("Paste Trimmed");
      pasteTrimmedItem.connect("activate", () => {
        this.watcher.pasteTrimmed(St.ClipboardType.CLIPBOARD).catch(logError);
      });
      const pasteOriginalItem = new PopupMenu.PopupMenuItem("Paste Original");
      pasteOriginalItem.connect("activate", () => {
        this.watcher.pasteOriginal(St.ClipboardType.CLIPBOARD).catch(logError);
      });
      const restoreItem = new PopupMenu.PopupMenuItem("Restore last copy");
      restoreItem.connect("activate", () => {
        this.watcher.restore(St.ClipboardType.CLIPBOARD);
      });
      const prefsItem = new PopupMenu.PopupMenuItem("Preferences\u2026");
      prefsItem.connect("activate", () => {
        if (this.openPrefs) {
          this.openPrefs();
        } else {
          log("Trimmeh: preferences callback not set");
        }
      });
      this.menu.addMenuItem(this.autoItem);
      this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
      this.menu.addMenuItem(pasteTrimmedItem);
      this.menu.addMenuItem(pasteOriginalItem);
      this.menu.addMenuItem(restoreItem);
      this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
      this.menu.addMenuItem(prefsItem);
      this.settings.connect("changed::enable-auto-trim", () => {
        this.autoItem.setToggleState(this.settings.get_boolean("enable-auto-trim"));
        this.updateIconState();
      });
      this.watcher.onSummaryChanged = (summary) => {
        this.updateSummary(summary);
      };
      if (this.watcher.lastSummary) {
        this.updateSummary(this.watcher.lastSummary);
      }
      this.updateIconState();
    }
    updateSummary(summary) {
      this.summaryItem.label.text = summary || "No actions yet";
    }
    updateIconState() {
      const enabled = this.settings.get_boolean("enable-auto-trim");
      this.icon.opacity = enabled ? 255 : 120;
    }
    addToPanel() {
      Main.panel.addToStatusArea("trimmeh-panel", this);
    }
    destroy() {
      super.destroy();
    }
  }
);

// shell-extension/src/clipboard.ts
import St2 from "gi://St";

// shell-extension/src/clipboardWatcher.ts
import GLib from "gi://GLib";
var DEFAULT_GRACE_DELAY_MS = 80;
var DEFAULT_POLL_INTERVAL_MS = 800;
var ClipboardWatcher = class {
  constructor(clipboard, trimmer, settings, opts = {}) {
    this.clipboard = clipboard;
    this.trimmer = trimmer;
    this.settings = settings;
    this.enabled = false;
    this.signals = [];
    this.pollId = null;
    this.states = /* @__PURE__ */ new Map();
    /** Latest single-line preview of the last trim/paste action. */
    this.lastSummary = "";
    /** Optional hook for UI to observe summary changes. */
    this.onSummaryChanged = null;
    this.graceDelayMs = opts.graceDelayMs ?? DEFAULT_GRACE_DELAY_MS;
    this.pollIntervalMs = opts.pollIntervalMs ?? DEFAULT_POLL_INTERVAL_MS;
  }
  enable(selections = []) {
    this.enabled = true;
    try {
      const id = this.clipboard.connect_owner_change((selection) => {
        this.onOwnerChange(selection);
      });
      this.signals.push(id);
    } catch (e) {
      log(`Trimmeh: owner-change not available, falling back to polling: ${e}`);
      this.startPolling(selections);
    }
    selections.forEach((sel) => this.onOwnerChange(sel));
  }
  disable() {
    this.enabled = false;
    this.signals.forEach((sig) => this.clipboard.disconnect(sig));
    this.signals = [];
    this.states.forEach((state) => {
      if (state.debounceId !== null) {
        GLib.source_remove(state.debounceId);
        state.debounceId = null;
      }
      state.pendingGen = null;
    });
    if (this.pollId !== null) {
      GLib.source_remove(this.pollId);
      this.pollId = null;
    }
  }
  restore(selection) {
    const state = this.getState(selection);
    const original = state.lastOriginal;
    if (!original) {
      return;
    }
    this.internalWrite(selection, original, "restore", true);
  }
  /**
   * One-shot: temporarily replace clipboard with trimmed text (High aggr),
   * call pasteFn to inject paste, then restore previous clipboard.
   */
  async pasteTrimmed(selection, pasteFn, restoreDelayMs = 200) {
    const prevText = await this.readText(selection);
    if (!prevText) {
      return;
    }
    const opts = this.readOptions();
    const result = this.trimmer.trim(prevText, "high", opts);
    const toPaste = result.changed ? result.output : prevText;
    if (toPaste !== prevText) {
      const state = this.getState(selection);
      state.lastOriginal = prevText;
      state.lastTrimmed = toPaste;
      this.internalWrite(selection, toPaste, "manual");
    }
    try {
      await pasteFn();
    } catch (e) {
      logError(e);
    }
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, restoreDelayMs, () => {
      if (this.enabled) {
        this.internalWrite(selection, prevText, "restore", true);
      }
      return GLib.SOURCE_REMOVE;
    });
  }
  /**
   * One-shot: temporarily replace clipboard with original (untrimmed) text,
   * call pasteFn, then restore previous clipboard.
   */
  async pasteOriginal(selection, pasteFn, restoreDelayMs = 200) {
    const prevText = await this.readText(selection);
    if (!prevText) {
      return;
    }
    const state = this.getState(selection);
    const original = state.lastOriginal ?? prevText;
    if (original !== prevText) {
      this.internalWrite(selection, original, "manual");
    }
    try {
      await pasteFn();
    } catch (e) {
      logError(e);
    }
    if (original === prevText) {
      return;
    }
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, restoreDelayMs, () => {
      if (this.enabled) {
        this.internalWrite(selection, prevText, "restore", true);
      }
      return GLib.SOURCE_REMOVE;
    });
  }
  // ---- internals ----
  startPolling(selections) {
    if (this.pollId !== null) {
      GLib.source_remove(this.pollId);
    }
    this.pollId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, this.pollIntervalMs, () => {
      if (!this.enabled) {
        return GLib.SOURCE_REMOVE;
      }
      selections.forEach((sel) => this.onOwnerChange(sel));
      return GLib.SOURCE_CONTINUE;
    });
  }
  onOwnerChange(selection) {
    if (!this.enabled) {
      return;
    }
    const state = this.getState(selection);
    state.gen += 1;
    state.pendingGen = state.gen;
    if (state.debounceId !== null) {
      GLib.source_remove(state.debounceId);
      state.debounceId = null;
    }
    const scheduledGen = state.pendingGen;
    state.debounceId = GLib.timeout_add(
      GLib.PRIORITY_DEFAULT,
      this.graceDelayMs,
      () => {
        state.debounceId = null;
        if (scheduledGen !== null) {
          this.process(selection, scheduledGen).catch(logError);
        }
        return GLib.SOURCE_REMOVE;
      }
    );
  }
  async process(selection, genAtSchedule) {
    if (!this.enabled) {
      return;
    }
    const state = this.getState(selection);
    if (state.pendingGen !== genAtSchedule) {
      return;
    }
    const text = await this.readText(selection);
    if (!this.enabled || state.pendingGen !== genAtSchedule) {
      return;
    }
    if (!text) {
      return;
    }
    const nowUsec2 = GLib.get_monotonic_time();
    if (state.restoreGuard) {
      if (nowUsec2 > state.restoreGuard.expiresUsec) {
        state.restoreGuard = null;
      } else {
        const incomingHash2 = hashText(text);
        if (incomingHash2 === state.restoreGuard.hash) {
          return;
        }
        state.restoreGuard = null;
      }
    }
    const incomingHash = hashText(text);
    if (state.lastWrittenHash && incomingHash === state.lastWrittenHash) {
      state.lastWrittenHash = null;
      state.lastWriteKind = null;
      return;
    }
    if (!this.settings.get_boolean("enable-auto-trim")) {
      return;
    }
    const opts = this.readOptions();
    const aggr = this.settings.get_string("aggressiveness");
    const result = this.trimmer.trim(text, aggr, opts);
    if (!result.changed) {
      return;
    }
    if (!this.enabled || state.pendingGen !== genAtSchedule) {
      return;
    }
    state.lastOriginal = text;
    this.internalWrite(selection, result.output, "trim");
  }
  readOptions() {
    return {
      keep_blank_lines: this.settings.get_boolean("keep-blank-lines"),
      strip_box_chars: this.settings.get_boolean("strip-box-chars"),
      trim_prompts: this.settings.get_boolean("trim-prompts"),
      max_lines: this.settings.get_int("max-lines")
    };
  }
  readText(selection) {
    return new Promise((resolve) => {
      this.clipboard.get_text(selection, (_text) => {
        resolve(_text);
      });
    });
  }
  getState(selection) {
    let state = this.states.get(selection);
    if (!state) {
      state = {
        gen: 0,
        pendingGen: null,
        debounceId: null,
        lastWrittenHash: null,
        lastWriteKind: null,
        restoreGuard: null,
        lastOriginal: null,
        lastTrimmed: null
      };
      this.states.set(selection, state);
    }
    return state;
  }
  internalWrite(selection, text, kind, withRestoreGuard = false) {
    const state = this.getState(selection);
    const hash = hashText(text);
    state.lastWrittenHash = hash;
    state.lastWriteKind = kind;
    if (withRestoreGuard) {
      const expiresUsec = GLib.get_monotonic_time() + 15e5;
      state.restoreGuard = { hash, expiresUsec };
    }
    this.updateSummary(text);
    this.clipboard.set_text(selection, text);
  }
  updateSummary(text) {
    const singleLine = text.replace(/\n+/g, " ").trim();
    const limit = 100;
    let summary = singleLine;
    if (summary.length > limit) {
      const keep = limit - 1;
      const head = Math.floor(keep / 2);
      const tail = keep - head;
      summary = `${summary.slice(0, head)}\u2026${summary.slice(summary.length - tail)}`;
    }
    this.lastSummary = summary;
    this.onSummaryChanged?.(summary);
  }
};
function hashText(text) {
  return GLib.compute_checksum_for_string(GLib.ChecksumType.SHA256, text, -1);
}

// shell-extension/src/virtualPaste.ts
import Clutter from "gi://Clutter";
import GLib2 from "gi://GLib";
var virtualKeyboard = null;
function getVirtualKeyboard() {
  if (virtualKeyboard) {
    return virtualKeyboard;
  }
  const seat = Clutter.get_default_backend().get_default_seat();
  virtualKeyboard = seat.create_virtual_device(Clutter.InputDeviceType.KEYBOARD_DEVICE);
  return virtualKeyboard;
}
function nowUsec() {
  return GLib2.get_monotonic_time();
}
function currentModifierMask() {
  try {
    const res = global.get_pointer?.();
    if (Array.isArray(res) && res.length >= 3) {
      return res[2];
    }
  } catch (e) {
  }
  return 0;
}
async function waitForHotkeyModifiersUp(timeoutMs = 250) {
  const mask = Clutter.ModifierType.SUPER_MASK | Clutter.ModifierType.MOD1_MASK | Clutter.ModifierType.SHIFT_MASK;
  const deadlineUsec = GLib2.get_monotonic_time() + timeoutMs * 1e3;
  if ((currentModifierMask() & mask) === 0) {
    return false;
  }
  return await new Promise((resolve) => {
    GLib2.timeout_add(GLib2.PRIORITY_DEFAULT, 5, () => {
      const mods = currentModifierMask();
      const timedOut = GLib2.get_monotonic_time() >= deadlineUsec;
      if ((mods & mask) === 0 || timedOut) {
        resolve(timedOut);
        return GLib2.SOURCE_REMOVE;
      }
      return GLib2.SOURCE_CONTINUE;
    });
  });
}
function keyvalForChar(char) {
  const cp = char.codePointAt(0);
  if (cp === void 0) {
    return 0;
  }
  return Clutter.unicode_to_keysym(cp);
}
function pasteCtrlV() {
  const vk = getVirtualKeyboard();
  const t0 = nowUsec();
  const keyV = typeof Clutter.KEY_v === "number" && Clutter.KEY_v || typeof Clutter.KEY_V === "number" && Clutter.KEY_V || keyvalForChar("v");
  vk.notify_keyval(t0 + 0, Clutter.KEY_Control_L, Clutter.KeyState.PRESSED);
  vk.notify_keyval(t0 + 1, keyV, Clutter.KeyState.PRESSED);
  vk.notify_keyval(t0 + 2, keyV, Clutter.KeyState.RELEASED);
  vk.notify_keyval(t0 + 3, Clutter.KEY_Control_L, Clutter.KeyState.RELEASED);
}
function pasteShiftInsert() {
  const vk = getVirtualKeyboard();
  const t0 = nowUsec();
  vk.notify_keyval(t0 + 0, Clutter.KEY_Shift_L, Clutter.KeyState.PRESSED);
  vk.notify_keyval(t0 + 1, Clutter.KEY_Insert, Clutter.KeyState.PRESSED);
  vk.notify_keyval(t0 + 2, Clutter.KEY_Insert, Clutter.KeyState.RELEASED);
  vk.notify_keyval(t0 + 3, Clutter.KEY_Shift_L, Clutter.KeyState.RELEASED);
}
async function pasteWithFallback() {
  const startUsec = GLib2.get_monotonic_time();
  const timedOut = await waitForHotkeyModifiersUp();
  if (timedOut) {
    const mods = currentModifierMask();
    log(`Trimmeh: paste injection timed out waiting for modifiers; mods=${mods}`);
  }
  try {
    pasteShiftInsert();
  } catch (e) {
    logError(e);
    try {
      pasteCtrlV();
    } catch (e2) {
      logError(e2);
    }
  }
}

// shell-extension/src/clipboard.ts
var StClipboardAdapter = class {
  constructor() {
    this.clipboard = St2.Clipboard.get_default();
  }
  get_text(selection, cb) {
    this.clipboard.get_text(selection, (_clip, text) => cb(text));
  }
  set_text(selection, text) {
    this.clipboard.set_text(selection, text);
  }
  connect_owner_change(cb) {
    const handler = (_clip, selection) => cb(selection);
    return this.clipboard.connect("owner-change", handler);
  }
  disconnect(id) {
    this.clipboard.disconnect(id);
  }
};
var ClipboardWatcher2 = class extends ClipboardWatcher {
  constructor(trimmer, settings) {
    super(new StClipboardAdapter(), trimmer, settings);
  }
  enable() {
    super.enable([St2.ClipboardType.CLIPBOARD, St2.ClipboardType.PRIMARY]);
  }
  pasteTrimmed(selection = St2.ClipboardType.CLIPBOARD) {
    return super.pasteTrimmed(selection, pasteWithFallback);
  }
  pasteOriginal(selection = St2.ClipboardType.CLIPBOARD) {
    return super.pasteOriginal(selection, pasteWithFallback);
  }
};

// trimmeh-core-js/src/index.ts
var DEFAULT_TRIM_OPTIONS = {
  keep_blank_lines: false,
  strip_box_chars: true,
  trim_prompts: true,
  max_lines: 10
};
function trim(input, aggressiveness, options) {
  const opts = Object.assign({}, DEFAULT_TRIM_OPTIONS, options || {});
  const normalizedInput = normalizeNewlines(input);
  const lineCount = normalizedInput.split("\n").length;
  if (lineCount > opts.max_lines) {
    return {
      output: input,
      changed: false,
      reason: "skipped_too_large"
    };
  }
  let current = normalizedInput;
  let didPromptStrip = false;
  let didBoxStrip = false;
  let didBackslashMerge = false;
  if (opts.strip_box_chars) {
    const cleaned = stripBoxDrawingCharacters(current);
    if (cleaned !== null) {
      didBoxStrip = true;
      current = cleaned;
    }
  }
  if (opts.trim_prompts) {
    const stripped = stripPromptPrefixes(current);
    if (stripped !== null) {
      didPromptStrip = true;
      current = stripped;
    }
  }
  const repaired = repairWrappedUrl(current);
  if (repaired !== null) {
    current = repaired;
  }
  const cmd = transformIfCommand(current, aggressiveness, opts);
  if (cmd !== null) {
    current = cmd.output;
    didBackslashMerge = cmd.mergedBackslash;
  }
  const changed = current !== normalizedInput;
  const reason = !changed ? void 0 : didBackslashMerge ? "backslash_merged" : didBoxStrip ? "box_chars_removed" : didPromptStrip ? "prompt_stripped" : "flattened";
  return { output: current, changed, reason };
}
function normalizeNewlines(input) {
  return input.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
}
var BOX_CLASS = "\u2502\u2503\u254E\u254F\u2506\u2507\u250A\u250B\u257D\u257F\uFFE8\uFF5C";
var KNOWN_PREFIXES = [
  "sudo",
  "./",
  "~/",
  "apt",
  "brew",
  "git",
  "python",
  "pip",
  "pnpm",
  "npm",
  "yarn",
  "cargo",
  "bundle",
  "rails",
  "go",
  "make",
  "xcodebuild",
  "swift",
  "kubectl",
  "docker",
  "podman",
  "aws",
  "gcloud",
  "az",
  "ls",
  "cd",
  "cat",
  "echo",
  "env",
  "export",
  "open",
  "node",
  "java",
  "ruby",
  "perl",
  "bash",
  "zsh",
  "fish",
  "pwsh",
  "sh"
];
var RE_BLANK_PLACEHOLDER = /\n\s*\n/g;
var RE_HYPHEN_JOIN = /([A-Za-z0-9._~-])-\s*\n\s*([A-Za-z0-9._~-])/gm;
var RE_ADJ_WORD_JOIN = /([A-Z0-9_.-])\s*\n\s*([A-Z0-9_.-])/gm;
var RE_PATH_JOIN = /([/:~])\s*\n\s*([A-Za-z0-9._-])/gm;
var RE_BACKSLASH_NEWLINE = /\\\s*\n/g;
var RE_BACKSLASH_NEWLINE_TEST = /\\\s*\n/;
var RE_NEWLINES_TO_SPACE = /\n+/g;
var RE_SPACES = /\s+/g;
var RE_PIPE_OR_OP = /[|&]{1,2}/;
var RE_PROMPT_MARK = /(^|\n)\s*\$/m;
var RE_SUDO_CMD = /^\s*(sudo\s+)?[A-Za-z0-9./~_-]+\b/m;
var RE_PATH_TOKEN = /[A-Za-z0-9._~-]+\/[A-Za-z0-9._~-]+/;
var RE_LIST_BULLET = /^[-*•]\s+\S/;
var RE_LIST_NUMBERED = /^[0-9]+[.)]\s+\S/;
var RE_LIST_BARETOKEN = /^[A-Za-z0-9]{4,}$/;
var RE_SOURCE_KEYWORD = /^\s*(import|package|namespace|using|template|class|struct|enum|extension|protocol|interface|func|def|fn|let|var|public|private|internal|open|protected|if|for|while)\b/m;
function stripPromptPrefixes(text) {
  const lines = text.split("\n");
  const nonEmpty = lines.filter((l) => l.trim().length > 0);
  if (nonEmpty.length === 0) {
    return null;
  }
  let strippedCount = 0;
  const rebuilt = [];
  rebuilt.length = lines.length;
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    const stripped = stripPromptLine(line);
    if (stripped !== null) {
      strippedCount += 1;
      rebuilt[i] = stripped;
    } else {
      rebuilt[i] = line;
    }
  }
  const majority = Math.floor(nonEmpty.length / 2) + 1;
  const shouldStrip = nonEmpty.length === 1 ? strippedCount === 1 : strippedCount >= majority;
  if (!shouldStrip) {
    return null;
  }
  const result = rebuilt.join("\n");
  return result === text ? null : result;
}
function stripPromptLine(line) {
  const leadingMatch = line.match(/^\s*/);
  const leading = leadingMatch ? leadingMatch[0] : "";
  const remainder = line.slice(leading.length);
  if (remainder.length === 0) {
    return null;
  }
  const first = remainder[0];
  if (first !== "#" && first !== "$") {
    return null;
  }
  const afterPrompt = remainder.slice(1).trimStart();
  if (!isLikelyPromptCommand(afterPrompt)) {
    return null;
  }
  return `${leading}${afterPrompt}`;
}
function isLikelyPromptCommand(content) {
  const trimmed = content.trim();
  if (trimmed.length === 0) {
    return false;
  }
  const last = trimmed[trimmed.length - 1];
  if (last === "." || last === "?" || last === "!") {
    return false;
  }
  const hasPunct = /[-./~$]/.test(trimmed) || /\d/.test(trimmed);
  const firstToken = (trimmed.split(/\s+/)[0] || "").toLowerCase();
  const startsWithKnown = KNOWN_PREFIXES.some((p) => firstToken.startsWith(p));
  return (hasPunct || startsWithKnown) && isLikelyCommandLine(trimmed);
}
function stripBoxDrawingCharacters(text) {
  const boxAny = new RegExp(`[${BOX_CLASS}]`);
  if (!boxAny.test(text)) {
    return null;
  }
  let result = text;
  if (result.includes("\u2502 \u2502")) {
    result = result.split("\u2502 \u2502").join(" ");
  }
  const lines = result.split("\n");
  const nonEmpty = lines.map((l) => l.trim()).filter((l) => l.length > 0);
  const leadingPattern = new RegExp(`^\\s*[${BOX_CLASS}]+ ?`);
  const trailingPattern = new RegExp(` ?[${BOX_CLASS}]+\\s*$`);
  let stripLeading = false;
  let stripTrailing = false;
  if (nonEmpty.length > 0) {
    const majority = Math.floor(nonEmpty.length / 2) + 1;
    const leadingMatches = nonEmpty.filter((line) => leadingPattern.test(line)).length;
    const trailingMatches = nonEmpty.filter((line) => trailingPattern.test(line)).length;
    stripLeading = leadingMatches >= majority;
    stripTrailing = trailingMatches >= majority;
  }
  if (stripLeading || stripTrailing) {
    const rebuilt = [];
    rebuilt.length = lines.length;
    for (let i = 0; i < lines.length; i += 1) {
      let line = lines[i];
      if (stripLeading) {
        line = line.replace(leadingPattern, "");
      }
      if (stripTrailing) {
        line = line.replace(trailingPattern, "");
      }
      rebuilt[i] = line;
    }
    result = rebuilt.join("\n");
  }
  const boxAfterPipe = new RegExp(`\\|\\s*[${BOX_CLASS}]+\\s*`, "g");
  result = result.replace(boxAfterPipe, "| ");
  const boxPathJoin = new RegExp(`([:/])\\s*[${BOX_CLASS}]+\\s*([A-Za-z0-9])`, "g");
  result = result.replace(boxPathJoin, "$1$2");
  const boxMidToken = new RegExp(`(\\S)\\s*[${BOX_CLASS}]+\\s*(\\S)`, "g");
  result = result.replace(boxMidToken, "$1 $2");
  const boxAnywhere = new RegExp(`\\s*[${BOX_CLASS}]+\\s*`, "g");
  result = result.replace(boxAnywhere, " ");
  result = result.replace(/ {2,}/g, " ");
  const trimmed = result.trim();
  return trimmed === text ? null : trimmed;
}
function repairWrappedUrl(text) {
  const trimmed = text.trim();
  const lower = trimmed.toLowerCase();
  const schemeCount = countOccurrences(lower, "https://") + countOccurrences(lower, "http://");
  if (schemeCount !== 1) {
    return null;
  }
  if (!(lower.startsWith("http://") || lower.startsWith("https://"))) {
    return null;
  }
  const collapsed = trimmed.replace(/\s+/g, "");
  if (collapsed === trimmed) {
    return null;
  }
  const validUrl = /^https?:\/\/[A-Za-z0-9._~:/?#\[\]@!$&'()*+,;=%-]+$/;
  return validUrl.test(collapsed) ? collapsed : null;
}
function countOccurrences(haystack, needle) {
  if (needle.length === 0) {
    return 0;
  }
  let count = 0;
  let idx = 0;
  for (; ; ) {
    const found = haystack.indexOf(needle, idx);
    if (found === -1) {
      break;
    }
    count += 1;
    idx = found + needle.length;
  }
  return count;
}
function transformIfCommand(text, aggressiveness, opts) {
  if (!text.includes("\n")) {
    return null;
  }
  const lines = text.split("\n");
  if (lines.length < 2) {
    return null;
  }
  if (lines.length > 10) {
    return null;
  }
  const newlineCount = lines.length - 1;
  const overrideHigh = aggressiveness === "high";
  if (!overrideHigh && newlineCount > 4) {
    return null;
  }
  const nonEmpty = lines.filter((l) => l.trim().length > 0);
  if (!overrideHigh && isLikelyList(nonEmpty)) {
    return null;
  }
  const hasLineContinuation = text.includes("\\\n");
  const hasLineJoinerAtEol = /(\\|[|&]{1,2}|;)\s*$/m.test(text);
  const hasIndentedPipeline = /^\s*[|&]{1,2}\s+\S/m.test(text);
  const hasExplicitJoin = hasLineContinuation || hasLineJoinerAtEol || hasIndentedPipeline;
  const cmdLineCount = commandLineCount(nonEmpty);
  if (!overrideHigh && !hasExplicitJoin && cmdLineCount === nonEmpty.length && nonEmpty.length >= 3) {
    return null;
  }
  const strongSignals = hasLineContinuation || RE_PIPE_OR_OP.test(text) || RE_PROMPT_MARK.test(text) || RE_PATH_TOKEN.test(text);
  const hasKnownPrefix = containsKnownCommandPrefix(nonEmpty);
  if (!overrideHigh && !strongSignals && !hasKnownPrefix && !hasCommandPunctuation(text)) {
    return null;
  }
  if (!overrideHigh && isLikelySourceCode(text) && !strongSignals) {
    return null;
  }
  let score = 0;
  if (hasLineContinuation) {
    score += 1;
  }
  if (RE_PIPE_OR_OP.test(text)) {
    score += 1;
  }
  if (RE_PROMPT_MARK.test(text)) {
    score += 1;
  }
  if (nonEmpty.length > 0 && nonEmpty.every((l) => isLikelyCommandLine(l))) {
    score += 1;
  }
  if (RE_SUDO_CMD.test(text)) {
    score += 1;
  }
  if (RE_PATH_TOKEN.test(text)) {
    score += 1;
  }
  const threshold = aggressiveness === "low" ? 3 : aggressiveness === "normal" ? 2 : 1;
  if (score < threshold) {
    return null;
  }
  const flattened = flatten(text, opts.keep_blank_lines);
  if (flattened.output === text) {
    return null;
  }
  return flattened;
}
function isLikelyCommandLine(line) {
  const trimmed = line.trim();
  if (trimmed.length === 0) {
    return false;
  }
  if (trimmed.startsWith("[[")) {
    return true;
  }
  if (trimmed.endsWith(".")) {
    return false;
  }
  return /^(sudo\s+)?[A-Za-z0-9./~_-]+(?:\s+|$)/.test(trimmed);
}
function containsKnownCommandPrefix(lines) {
  return lines.some((line) => {
    const trimmed = line.trim();
    if (trimmed.length === 0) {
      return false;
    }
    const first = trimmed.split(/\s+/)[0] || "";
    const lower = first.toLowerCase();
    return KNOWN_PREFIXES.some((p) => lower.startsWith(p));
  });
}
function hasCommandPunctuation(text) {
  return /[./~_=:-]/.test(text);
}
function isLikelyList(lines) {
  if (lines.length === 0) {
    return false;
  }
  const listish = lines.filter((line) => {
    const trimmed = line.trim();
    if (trimmed.length === 0) {
      return false;
    }
    const hasSpaces = /\s/.test(trimmed);
    if (RE_LIST_BULLET.test(trimmed)) {
      return true;
    }
    if (RE_LIST_NUMBERED.test(trimmed)) {
      return true;
    }
    if (!hasSpaces && RE_LIST_BARETOKEN.test(trimmed) && !trimmed.includes(".") && !trimmed.includes("/") && !trimmed.includes("$")) {
      return true;
    }
    return false;
  }).length;
  return listish >= Math.floor(lines.length / 2) + 1;
}
function isLikelySourceCode(text) {
  const hasBraces = text.includes("{") || text.includes("}") || text.toLowerCase().includes("begin");
  const hasKeywords = RE_SOURCE_KEYWORD.test(text);
  return hasBraces && hasKeywords;
}
function commandLineCount(lines) {
  return lines.filter(isLikelyCommandLine).length;
}
function flatten(text, preserveBlankLines) {
  let result = text;
  if (preserveBlankLines) {
    result = result.replace(RE_BLANK_PLACEHOLDER, "__TRIMMEH_BLANK__PLACEHOLDER__");
  }
  result = result.replace(RE_HYPHEN_JOIN, "$1-$2");
  result = result.replace(RE_ADJ_WORD_JOIN, "$1$2");
  result = result.replace(RE_PATH_JOIN, "$1$2");
  let mergedBackslash = false;
  if (RE_BACKSLASH_NEWLINE_TEST.test(result)) {
    mergedBackslash = true;
    result = result.replace(RE_BACKSLASH_NEWLINE, " ");
  }
  result = result.replace(RE_NEWLINES_TO_SPACE, " ");
  result = result.replace(RE_SPACES, " ");
  if (preserveBlankLines) {
    result = result.split("__TRIMMEH_BLANK__PLACEHOLDER__").join("\n\n");
  }
  return { output: result.trim(), mergedBackslash };
}

// shell-extension/src/trimmer.ts
function createTrimAdapter() {
  return {
    trim: (text, aggressiveness, options) => {
      const res = trim(text, aggressiveness, options);
      return {
        output: res.output,
        changed: res.changed,
        reason: res.reason,
        hash_hex: ""
      };
    }
  };
}

// shell-extension/src/extension.ts
import * as Main2 from "resource:///org/gnome/shell/ui/main.js";
import Meta from "gi://Meta";
import Shell from "gi://Shell";
var TrimmehExtension = class extends Extension {
  constructor() {
    super(...arguments);
    this.watcher = null;
    this.panelIndicator = null;
    this.keybindingNames = [];
  }
  async enable() {
    const settings = this.getSettings();
    const trimmer = createTrimAdapter();
    this.watcher = new ClipboardWatcher2(trimmer, settings);
    this.watcher.enable();
    this.addKeybindings(settings);
    this.panelIndicator = new PanelIndicatorClass(settings, this.watcher, () => {
      this.openPreferences();
    });
    this.panelIndicator.addToPanel();
  }
  disable() {
    this.removeKeybindings();
    this.watcher?.disable();
    this.watcher = null;
    this.panelIndicator?.destroy();
    this.panelIndicator = null;
  }
  addKeybindings(settings) {
    const actionMode = Shell?.ActionMode;
    const mode = (actionMode?.NORMAL ?? 0) | (actionMode?.OVERVIEW ?? 0);
    const flags = Meta?.KeyBindingFlags?.IGNORE_AUTOREPEAT ?? Meta?.KeyBindingFlags?.NONE ?? 0;
    const add = (name, handler) => {
      try {
        Main2.wm.addKeybinding(name, settings, flags, mode, handler);
        Main2.wm.allowKeybinding?.(name, mode);
        this.keybindingNames.push(name);
      } catch (e) {
        logError(e);
      }
    };
    add("paste-trimmed-hotkey", () => {
      this.watcher?.pasteTrimmed().catch(logError);
    });
    add("paste-original-hotkey", () => {
      this.watcher?.pasteOriginal().catch(logError);
    });
    add("toggle-auto-trim-hotkey", () => {
      const current = settings.get_boolean("enable-auto-trim");
      settings.set_boolean("enable-auto-trim", !current);
    });
  }
  removeKeybindings() {
    for (const name of this.keybindingNames) {
      try {
        if (Main2.wm.removeKeybinding) {
          Main2.wm.removeKeybinding(name);
        } else if (global.display?.remove_keybinding) {
          global.display.remove_keybinding(name);
        }
      } catch (e) {
        logError(e);
      }
    }
    this.keybindingNames = [];
  }
};
export {
  TrimmehExtension as default
};
